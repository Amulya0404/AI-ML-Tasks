"""Train, tune, compare and save the model. Run from the project root: python src/train.py"""
import json
import joblib
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split

from pipeline import RAW_FEATURES, TARGET, build_pipeline, load_and_clean

RANDOM_STATE = 42


def main():
    df, n_dups = load_and_clean()
    X, y = df[RAW_FEATURES], df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=RANDOM_STATE)
    print(f"Rows after dedup: {len(df)} (removed {n_dups}) | train {len(X_train)} / test {len(X_test)}")

    candidates = {
        "Logistic Regression": (LogisticRegression(max_iter=2000, random_state=RANDOM_STATE),
                                {"clf__C": [0.01, 0.1, 1, 10]}),
        "Random Forest": (RandomForestClassifier(random_state=RANDOM_STATE),
                          {"clf__n_estimators": [200, 400], "clf__max_depth": [4, 6, 8],
                           "clf__min_samples_leaf": [1, 3, 5]}),
        "Gradient Boosting": (GradientBoostingClassifier(random_state=RANDOM_STATE),
                              {"clf__n_estimators": [100, 200], "clf__learning_rate": [0.03, 0.1],
                               "clf__max_depth": [2, 3]}),
    }
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    rows, fitted = [], {}
    for name, (clf, grid) in candidates.items():
        gs = GridSearchCV(build_pipeline(clf), grid, cv=cv, scoring="roc_auc", n_jobs=-1)
        gs.fit(X_train, y_train)
        pred, proba = gs.predict(X_test), gs.predict_proba(X_test)[:, 1]
        rows.append({"model": name,
                     "best_params": json.dumps({k.replace("clf__", ""): v for k, v in gs.best_params_.items()}),
                     "cv_roc_auc": gs.best_score_,
                     "test_accuracy": accuracy_score(y_test, pred), "test_precision": precision_score(y_test, pred),
                     "test_recall": recall_score(y_test, pred), "test_f1": f1_score(y_test, pred),
                     "test_roc_auc": roc_auc_score(y_test, proba)})
        fitted[name] = gs.best_estimator_
        print(name, "done")

    res = pd.DataFrame(rows).set_index("model")
    # Model selection uses CROSS-VALIDATION on the training data only (not the test set)
    best = res["cv_roc_auc"].idxmax()
    res.round(4).to_csv("reports/model_comparison.csv")
    print(res.drop(columns="best_params").round(3).to_string())
    print("Selected model (highest CV ROC-AUC):", best)

    # Refit the winner (same tuned settings) on ALL data for the deployed model.
    # The held-out test metrics above remain the honest performance estimate.
    final = clone(fitted[best])
    final.fit(X, y)
    joblib.dump(final, "models/best_model.joblib")
    joblib.dump(fitted, "models/all_tuned_models.joblib")
    json.dump({"selected_model": best, "n_rows": len(df), "duplicates_removed": int(n_dups),
               "train_size": len(X_train), "test_size": len(X_test)},
              open("models/model_info.json", "w"), indent=2)
    print("Saved models/best_model.joblib")


if __name__ == "__main__":
    main()
