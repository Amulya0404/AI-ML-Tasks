"""Shared data-loading, cleaning and model-pipeline code for the Titanic survival project."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, OneHotEncoder, StandardScaler

# Raw passenger fields the user (or app) provides
RAW_FEATURES = ["pclass", "sex", "age", "sibsp", "parch", "fare", "embarked"]
TARGET = "survived"


def load_and_clean(path="data/titanic_raw.csv"):
    """Keep the useful raw columns and drop duplicate records.

    Missing values are NOT filled here: imputation lives inside the model
    pipeline so it is learned from training data only (no data leakage).
    """
    df = pd.read_csv(path)[RAW_FEATURES + [TARGET]]
    n_before = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    return df, n_before - len(df)


def add_features(X):
    """Feature engineering: family size, alone flag, log-transformed fare."""
    X = X.copy()
    X["family_size"] = X["sibsp"] + X["parch"] + 1
    X["is_alone"] = (X["family_size"] == 1).astype(int)
    X["fare_log"] = np.log1p(X["fare"])
    return X.drop(columns=["fare"])


def build_preprocessor():
    numeric = ["age", "sibsp", "parch", "family_size", "fare_log"]
    categorical = ["pclass", "sex", "embarked"]
    return ColumnTransformer([
        ("num", Pipeline([("impute", SimpleImputer(strategy="median")),
                          ("scale", StandardScaler())]), numeric),
        ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                          ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical),
    ], remainder="passthrough")  # is_alone (0/1) passes through


def build_pipeline(classifier):
    """Full pipeline: raw passenger fields -> features -> preprocessing -> classifier."""
    return Pipeline([
        ("features", FunctionTransformer(add_features)),
        ("prep", build_preprocessor()),
        ("clf", classifier),
    ])
