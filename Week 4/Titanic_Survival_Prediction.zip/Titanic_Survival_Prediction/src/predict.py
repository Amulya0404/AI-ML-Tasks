"""Prediction system. Usage:
    python src/predict.py --pclass 1 --sex female --age 29 --sibsp 0 --parch 0 --fare 80 --embarked C
"""
import argparse
import os
import sys
import joblib
import pandas as pd

sys.path.insert(0, os.path.dirname(__file__))  # so the saved pipeline can find pipeline.add_features
from pipeline import RAW_FEATURES  # noqa: E402

MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "best_model.joblib")
_model = None


def load_model():
    global _model
    if _model is None:
        _model = joblib.load(MODEL_PATH)
    return _model


def predict_passenger(pclass, sex, age, sibsp, parch, fare, embarked):
    """Return the predicted outcome and survival probability for one passenger."""
    row = pd.DataFrame([{"pclass": int(pclass), "sex": sex, "age": age, "sibsp": int(sibsp),
                         "parch": int(parch), "fare": float(fare), "embarked": embarked}])[RAW_FEATURES]
    prob = float(load_model().predict_proba(row)[0, 1])
    return {"survived": prob >= 0.5, "survival_probability": prob}


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Predict Titanic survival for one passenger")
    ap.add_argument("--pclass", type=int, choices=[1, 2, 3], required=True)
    ap.add_argument("--sex", choices=["male", "female"], required=True)
    ap.add_argument("--age", type=float, default=None, help="leave out if unknown")
    ap.add_argument("--sibsp", type=int, default=0)
    ap.add_argument("--parch", type=int, default=0)
    ap.add_argument("--fare", type=float, required=True)
    ap.add_argument("--embarked", choices=["S", "C", "Q"], default="S")
    a = ap.parse_args()
    r = predict_passenger(a.pclass, a.sex, a.age if a.age is not None else float("nan"),
                          a.sibsp, a.parch, a.fare, a.embarked)
    print(f"Prediction: {'SURVIVED' if r['survived'] else 'DID NOT SURVIVE'} "
          f"(survival probability {r['survival_probability']:.1%})")
